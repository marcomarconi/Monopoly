Data List: CPI
Data Updated: 2022-09-14

FRED (Federal Reserve Economic Data)
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
Economic Research Division
Federal Reserve Bank of St. Louis

Series ID                                                             
----------------------------------------------------------------------
AUTCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Austria                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
BELCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Belgium                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
BRACPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Brazil                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CANCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index of All Items in Canada                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CANCPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for Canada  

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CHECPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Switzerland                       

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CHECPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for         
Switzerland                                                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CHLCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Chile                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CHNCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for China                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
CZECPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Czech Republic                    

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
DEUCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index of All Items in Germany                          

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
DEUCPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for Germany 

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
DEUCPIHICMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items (Harmonized Index of Consumer Prices) 
for Germany                                                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
DNKCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Denmark                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ESPCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Spain                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ESPCPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for Spain   

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ESPCPIHICMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items (Harmonized Index of Consumer Prices) 
for Spain                                                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
FINCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Finland                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
FRACPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index of All Items in France                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
FRACPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for France  

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
FRACPIHICMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items (Harmonized Index of Consumer Prices) 
for France                                                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
GBRCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index of All Items in the United Kingdom               

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
GBRCPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for United  
Kingdom                                                               

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
GRCCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Greece                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
HUNCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Hungary                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
IDNCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Indonesia                         

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
INDCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for India                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
IRLCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Ireland                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ISLCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Iceland                           

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ISRCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Israel                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ITACPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index of All Items in Italy                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ITACPIHICMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items (Harmonized Index of Consumer Prices) 
for Italy                                                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
JPNCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index of All Items in Japan                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
JPNCPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for Japan   

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
KORCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Korea                             

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
KORCPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for Korea   

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
LUXCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Luxembourg                        

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
MEXCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Mexico                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
NLDCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Netherlands                       

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
NORCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Norway                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
POLCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Poland                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
PRTCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Portugal                          

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
RUSCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Russian Federation                

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
SVKCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Slovak Republic                   

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
SVNCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Slovenia                          

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
SWECPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Sweden                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
TURCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for Turkey                            

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
USACPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for the United States                 

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
USACPICORMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items Excluding Food and Energy for the     
United States                                                         

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



Series ID                                                             
----------------------------------------------------------------------
ZAFCPIALLMINMEI                                                       

Title
----------------------------------------------------------------------
Consumer Price Index: All Items for South Africa                      

Source
----------------------------------------------------------------------
Organization for Economic Co-operation and Development                

Release
----------------------------------------------------------------------
Main Economic Indicators                                              

Units
----------------------------------------------------------------------
Index 2015=100                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Copyright, 2016, OECD. Reprinted with permission.                     
                                                                      
All OECD data should be cited as follows: OECD (2010), "Main Economic 
Indicators - complete database", Main Economic Indicators             
(database),http://dx.doi.org/10.1787/data-00052-en (Accessed on date) 



